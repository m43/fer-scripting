#!/bin/bash

if [ -z "$1" ]; then
	echo "Neispravan poziv"
	exit 1
fi

exit 0
